<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Visited;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $getip = Visited::get_ip();
        $getbrowsers = Visited::get_browser();
        $getdevice = Visited::get_device();
        $getso = Visited::get_os();

        /*$data= new Visitor;
        $data->ip=$getip;
        $data->browsers=$getbrowsers;
        $data->device=$getdevice;
        $data->so=$getso;
        $data->save();*/
        return view('backend.Dashboard', compact('getip','getbrowsers','getdevice','getso'));
    }
}
