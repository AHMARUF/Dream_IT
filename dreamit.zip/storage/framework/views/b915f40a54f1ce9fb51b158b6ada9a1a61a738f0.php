
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-user-friends"></i>
              </div>
              <div class="mr-5">Team Member</div>
              <strong style="font-size: 20px;">10</strong>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('/Teamall')); ?>">
              <span class="float-left">View Details</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-list"></i>
              </div>
              <div class="mr-5">Slider</div>
              <strong style="font-size: 20px;">10</strong>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('/sliderall')); ?>">
              <span class="float-left">View Details</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-success o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fab fa-fw fa-servicestack"></i>
              </div>
              <div class="mr-5">Service</div>
              <strong style="font-size: 20px;">10</strong>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('/Serviceall')); ?>">
              <span class="float-left">View Details</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-danger o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-eye"></i>
              </div>
              <div class="mr-5">visitor</div>
              <strong style="font-size: 20px;">10</strong>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left">View Details</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row">
          <div class="col-md-4 bg-light">
           <table>
            <tr>
              <td style="text-align: center;"><canvas id="canvas_tt607c0c102ae86" width="250" height="250" style="padding-top: 30%; padding-left: 20%;"></canvas>
              </td>
            </tr>
            <tr>
              <td style="text-align: center; font-weight: bold"><a href="http://24timezones.com/current_time/bangladesh_dhaka_clock.php" style="text-decoration: none" class="clock24" id="tz24-1618742288-c210387-eyJiZ2NvbG9yIjoiRkZGRkZGIiwibGFuZyI6ImVuIiwidHlwZSI6ImEiLCJzaXplIjoiMjUwIiwiY2FudmFzX2lkIjoiY2FudmFzX3R0NjA3YzBjMTAyYWU4NiJ9" title="Time in Dhaka" target="_blank"></a>
              </td>
            </tr>
          </table>
          <script type="text/javascript" src="//w.24timezones.com/l.js" async></script>
          </div>

          <div class="col-md-8 bg-light pt-3">
            <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Subscribe</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th>Age</th>
                  <th>Start date</th>
                  <th>Salary</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th>Age</th>
                  <th>Start date</th>
                  <th>Salary</th>
                </tr>
              </tfoot>
              <tbody>
                <tr>
                  <td>Tiger Nixon</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td>61</td>
                  <td>2011/04/25</td>
                  <td>$320,800</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
          </div>
        </div>
      </div>

      <div class="container mt-4 mb-4">
        <div class="row">
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Slider</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Service</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Portfolio</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Team</h4>
                </div>
              </div>
            </a>  
          </div>
           <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Slider</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Service</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Portfolio</h4>
                </div>
              </div>
            </a>  
          </div>
          <div class="col-md-3 col-sm-4 col-6 mt-2">
            <a href="" style="text-decoration: none; color:#000;">
              <div class="card bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-user fa-3x"></i>
                  <h4>Team</h4>
                </div>
              </div>
            </a>  
          </div>
        </div>
      </div>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Visitor List</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th>Age</th>
                  <th>Start date</th>
                  <th>Salary</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th>Age</th>
                  <th>Start date</th>
                  <th>Salary</th>
                </tr>
              </tfoot>
              <tbody>
                <tr>
                  <td>Tiger Nixon</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td>61</td>
                  <td>2011/04/25</td>
                  <td>$320,800</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamIT\resources\views/backend/Dashboard.blade.php ENDPATH**/ ?>