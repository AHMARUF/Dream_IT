
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-8 m-auto py-2 border-red" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);">
				<div class="card" >
					 <?php if($errors->any()): ?>
				      <div class="alert alert-danger">
				          <ul>
				              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                  <li><?php echo e($error); ?></li>
				              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				          </ul>
				      </div>
				    <?php endif; ?>
	                <div class="card-body">
	                    <h4 class="card-title">Gallery Eidt Page</h4><hr>
	                    <form class="mt-4" method="POST" action="<?php echo e(URL::to('Gallery/update/'.$Gallery->id)); ?>" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
	                        <div class="form-group">
	                        	<label>Title</label>
	                            <input type="text" class="form-control" name="title" value="<?php echo e($Gallery->title); ?>">
	                        </div>
	                        <div class="form-group">
	                        	<label>Category</label>
	                        	<select class="form-control" name="cat_id">
	                        		<option value="0">Select One...........</option>
	                        		<?php
	                        		$Category=App\Category::all();
	                        		?>
	                        		<?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        		<option value="<?php echo e($Categorys->id); ?>" <?php if($Gallery->cat_id==$Categorys->id) echo "selected"; ?>><?php echo e($Categorys->title); ?></option>
	                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        	</select>
	                        </div>
	                        <div class="form-group">
	                        	<label>Description</label>
	                            <textarea rows="4" class="form-control" name="description" ><?php echo e($Gallery->description); ?></textarea>
	                        </div>
	                         <div class="row">
	                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
	                        	<div class="form-group">
	                        	<label>File</label>
	                            <input type="file" class="form-control" name="images">
	                        </div>
	                        </div>
	                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 text-center">
	                        	<input type="hidden" name="old_photo" value="<?php echo e($Gallery->images); ?>">
	                        	<img src="<?php echo e(URL::to($Gallery->images)); ?>" height="100" width="130" class="img-fluid">
	                        </div>
	                    	</div>
	                        <div class="form-group">
	                            <button class="btn btn-success">UPDATE</button>
	                            <a href="<?php echo e(route('/Galleryall')); ?>" class="btn btn-primary">Back</a>
	                        </div>
	                    </form>
	                </div>
	            </div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamIT\resources\views/backend/portfolio/eidt.blade.php ENDPATH**/ ?>