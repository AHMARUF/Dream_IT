

<?php $__env->startSection('content'); ?>
		<!-- START CONTENT -->

<div id="content" class="site-content container zanaya-section-group z-np "  data-post-layout="-rows-2" data-pagination="splent_pagination" data-zanaya-content="Content">

	<div class="zanaya-row-group"  data-class-marker=&quot;classMark_row_hpupuo&quot;  data-row-layout=&quot;1|1&quot;  >
			
		<div id="primary" class="content-area zanaya-col-group col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-np" data-zanaya-content="Post"  >
			<main id="main" class="site-main">
							<div id="primary-content-wrapper">							<article id="post-14468" class="post-14468 page type-page status-publish hentry">
							
							<header class="entry-header hidden">
								<div class="entry-title"><h1 class="z-mt-0 zanaya-style-exclude">Retro Home</h1></div>							</header><!-- .entry-header -->
							
							<!-- featured image -->
														
<div class="entry-content">




	<div class="container zanaya-section text-lg-center classMark_section_XMwRJH animate-plus" id="div_XMwRJH" data-style-captured="true" data-class-marker="classMark_section_XMwRJH" data-animation-when-visible="true" data-animation-repeat="false" data-animation-reset-offscreen="false" data-animations="scaleOut" data-animation-duration="2s" data-animation-delay="0s" data-animation-group="_0" style="">

<div id="slider_EpkcT9" class="carousel zanaya-carousel zanaya-parallax-slider viewport-height skip-collision-shift theme2 clone-exclude-id zanaya-kb-wrapper classMark_slider_UfyPfa zanaya-elastic" data-ride="carousel" data-interval="5000" data-pause="hover" data-wrap="true" data-zanaya-element="slider" data-zanaya-element-theme="theme2" data-class-marker="classMark_slider_UfyPfa">



<ol class="carousel-indicators bottom center hidden">
 	<li data-target="#slider_EpkcT9" data-slide-to="0" class="zanaya-style-exclude active"></li>
 	<li data-target="#slider_EpkcT9" data-slide-to="1" class="zanaya-style-exclude"></li>
</ol>
<!-- Arrows  -->

<a class="zanaya-carousel-control zanaya-style-exclude hover-view" href="#slider_EpkcT9" data-slide="prev">
<span class="carousel-control-icon center left-side fa fa-chevron-left zanaya-style-exclude" id="i_rm7c06"></span>
</a>

<a class="zanaya-carousel-control zanaya-style-exclude hover-view" href="#slider_EpkcT9" data-slide="next">
<span class="carousel-control-icon center right-side fa fa-chevron-right zanaya-style-exclude" id="i_aNTGxN"></span>
</a>

<!-- Wrapper for slides -->
<div class="carousel-inner" role="listbox">

<?php
	$Slider = App\Slider::where('publication_status', 1)->get();
?>

<?php $__currentLoopData = $Slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$Sliders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(++$key==1): ?>
<div class="carousel-item item active">
<?php else: ?>
<div class="carousel-item item">
<?php endif; ?>
<div class="item-full-screen">





                   <!--
<div class="overlay"></div>
-->
<div class="parallax-slide zanaya-parallax zanaya-background zanaya-moving-parallax" data-width="1920" data-height="1275" id="div_odGlsw_<?php echo e(++$key); ?>" data-style-captured="true" data-parallax-bg-image="linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0)), url(&quot;<?php echo e(URL::to($Sliders->images)); ?>&quot;)"></div>
<div class="container zanaya-row zanaya-vertical-horizontal-align carousel-item-content classMark_row_hpupuo" data-row-layout="1|1" id="row_hpupuo" data-class-marker="classMark_row_hpupuo">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-col">
<div data-zanaya-element="image" class="clearfix">
    <img class="img-responsive pull-center-lg zanaya-keep-src animate-plus classMark_img_fPhrPQ" src="<?php echo e(asset('asset/favicon.ico')); ?>" alt="image description" id="img_fPhrPQ" data-class-marker="classMark_img_fPhrPQ" data-attachment-id="14158" data-animation-when-visible="true" data-animation-repeat="false" data-animation-reset-offscreen="false" data-animations="zoomIn" data-animation-duration="1s" data-animation-delay="0s" data-animation-group="_1" style=""></div>
<button class="btn zanaya-btn button-size-large button-text-small button-color-primary clearfix button-shape-sharp animate-plus classMark_button_0hIPH4" data-zanaya-element="button" id="button_0hIPH4" data-class-marker="classMark_button_0hIPH4" data-animation-when-visible="true" data-animation-repeat="false" data-animation-reset-offscreen="false" data-animations="fadeInUpSmall" data-animation-duration="1s" data-animation-delay="1s" data-animation-group="_2" style="">purchase
</button>

</div>
</div>
</div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>




</div>

</div>




<div class="container zanaya-section zanaya-background classMark_section_IJCfJZ" id="div_3WgDK3" data-class-marker="classMark_section_IJCfJZ">

<div class="zanaya-row clearfix container classMark_row_wxBYca text-lg-center" data-row-layout="1|3" id="div_i2Dbro" data-class-marker="classMark_row_wxBYca">

<?php 
	$Service = App\Service::where('publication_status', 1)->get();
?>

<?php $__currentLoopData = $Service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-xs-12 zanaya-col classMark_column_FHcQ0A col-lg-4 col-md-4 col-sm-4" id="div_F5EUPV" data-class-marker="classMark_column_FHcQ0A" >
<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col classMark_inner-column_9xbgAy" id="div_VjySN3" data-class-marker="classMark_inner-column_9xbgAy" >

	<img src="<?php echo e(URL::to($Services->images)); ?>" height="7
	0" width="70" style="border: 1px solid #158752; border-radius: 50%;">

						
</div>
</div>


<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col">
<div data-zanaya-element="text-block" class="clearfix">
<h4 id="h4_8V907A" class="classMark_h4_BH2N7E" data-class-marker="classMark_h4_BH2N7E"><?php echo e($Services->title); ?></h4>
</div>
<div data-zanaya-element="image" class="clearfix">
							<img class="img-responsive pull-center-lg zanaya-keep-src classMark_img_zKtwuS" src="https://retro.nouvellothemes.com/wp-content/uploads/2020/01/spacer.png" alt="image description" id="img_R6DnKP" data-class-marker="classMark_img_zKtwuS" data-attachment-id="14204"></div>
<div data-zanaya-element="text-block" class="clearfix">
<p class="zanaya-p classMark_p_LVivI8" id="p_dwlgYi" data-class-marker="classMark_p_LVivI8">
	<?php
		echo $Services->description;
	?>
</p>
</div>
<div data-zanaya-element="text-block" class="clearfix">
<p class="zanaya-p classMark_p_JfpY3y" id="p_UGdARA" data-class-marker="classMark_p_JfpY3y"></p>
</div>
</div>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>







<div class="container zanaya-section zanaya-background classMark_section_rqE8X2" id="div_uKwtrs" data-class-marker="classMark_section_rqE8X2">
<div class="zanaya-row clearfix container-fluid row classMark_row_7WSNwS" data-row-layout="1_2" id="div_b49HbO" data-class-marker="classMark_row_7WSNwS">
<div class="zanaya-col col-md-6 col-sm-12 col-xs-12 col-lg-7 classMark_column_u8QQw3" id="div_m8Mz0t" data-class-marker="classMark_column_u8QQw3">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-xs-12 empty zanaya-inner-col col-md-2 col-sm-5 classMark_inner-column_SE2fP3 col-lg-3" id="div_obuSOJ" data-class-marker="classMark_inner-column_SE2fP3"></div>
<div class="col-xs-12 zanaya-inner-col col-sm-12 col-md-8 classMark_inner-column_tgLD1H col-lg-7" id="div_ymJXid" data-class-marker="classMark_inner-column_tgLD1H">
<div data-zanaya-element="text-block" class="clearfix">
<h2 class="classMark_h2_S4ZNC7" id="h2_m8G0zv" data-class-marker="classMark_h2_S4ZNC7">Providing the best <span class="texteditor-inline-color classMark_span_lpONZO" id="span_EjGeiv" data-class-marker="classMark_span_lpONZO">Options</span></h2>
</div>
<div data-zanaya-element="text-block" class="clearfix">
<p class="zanaya-p">vivamus arcu felis bibendum ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla pellentesque dignissim enim sit amet venenatis</p>


</div>
<button class="btn zanaya-btn button-size-large button-text-small button-color-primary clearfix button-shape-sharp classMark_button_DJqjRs" data-zanaya-element="button" data-class-marker="classMark_button_DJqjRs">purchase
</button>

</div>
<div class="col-xs-12 zanaya-inner-col col-md-2 col-sm-5 col-lg-2 classMark_inner-column_xD7QMo" id="div_L0Fas0" data-class-marker="classMark_inner-column_xD7QMo">
						<a href="5806"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fa fa-play classMark_icon_UW18uy shadow-pulse" data-zanaya-element="icon" id="i_UW18uy" data-class-marker="classMark_icon_UW18uy" data-custom-classes="shadow-pulse"></i></a>

</div>
</div>
</div>
<div class="zanaya-col col-md-6 col-sm-12 col-xs-12 col-lg-5 classMark_column_5gJvsc" id="div_ttDG6l" data-class-marker="classMark_column_5gJvsc">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-lg-6 col-sm-6 col-xs-12 zanaya-inner-col classMark_inner-column_EjTrLR col-md-6" id="div_em5ItF" data-class-marker="classMark_inner-column_EjTrLR">
<div data-zanaya-element="image" class="clearfix">
							<img class="img-responsive pull-center-lg zanaya-keep-src classMark_img_xFMBra" src="https://retro.nouvellothemes.com/wp-content/uploads/2020/01/img5.jpg" alt="image description" id="img_nq310m" data-class-marker="classMark_img_xFMBra" data-attachment-id="14191"></div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 zanaya-inner-col classMark_inner-column_UvFcn4" id="div_7XjiDq" data-class-marker="classMark_inner-column_UvFcn4">
<div data-zanaya-element="image" class="clearfix">
							<img class="img-responsive zanaya-keep-src pull-right-lg classMark_img_9OqBTz" src="https://retro.nouvellothemes.com/wp-content/uploads/2020/01/img3-1.jpg" alt="image description" id="img_0ZDKed" data-class-marker="classMark_img_9OqBTz" data-attachment-id="14188"></div>
</div>
</div>
</div>
</div>
</div>



   <!-- ==========================
      Portfolio Section
    ============================-->
    <?php echo $__env->make('fontend.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <!-- #portfolio -->





<div class="container zanaya-section classMark_section_wVY5D6" id="div_yhehep" data-class-marker="classMark_section_wVY5D6">
<div class="zanaya-row clearfix container flex-row" data-row-layout="1|4">
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 zanaya-col">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-lg-6 zanaya-inner-col classMark_inner-column_Sf37Ht text-lg-right col-md-5 col-sm-5 col-xs-4" id="div_nAA5Lv" data-class-marker="classMark_inner-column_Sf37Ht">
						<i class="zanaya-icon clearfix zanaya-primary-color hidden-border xxl classMark_icon_r1lxoC fa fa-check" data-zanaya-element="icon" id="i_PSfncI" data-class-marker="classMark_icon_r1lxoC"></i>
</div>
<div class="col-lg-6 zanaya-inner-col col-md-9 col-sm-10 col-xs-9">
<div class="zanaya-counter clearfix zanaya-primary-color classMark_counter_CD7Fhz" data-zanaya-element="counter" data-counter-start="0" data-counter-end="87" data-counter-separator="" data-counter-decimals="" data-counter-duration="" data-counter-prefix="" data-counter-suffix="" id="div_CD7Fhz" data-class-marker="classMark_counter_CD7Fhz">18</div>
</div>
</div>
<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col classMark_inner-column_YYAgHk text-lg-center" id="div_71QUCR" data-class-marker="classMark_inner-column_YYAgHk">
<div data-zanaya-element="text-block" class="clearfix">
<h5 class="classMark_h5_mjgjom" id="h5_clVmOf" data-class-marker="classMark_h5_mjgjom">Advanced Features</h5>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 zanaya-col">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-lg-6 zanaya-inner-col classMark_inner-column_Sf37Ht text-lg-right col-md-5 col-sm-5 col-xs-4" id="div_VcuqGG" data-class-marker="classMark_inner-column_Sf37Ht">
						<i class="zanaya-icon clearfix zanaya-primary-color hidden-border xxl classMark_icon_4GjCeN fa fa-asterisk" data-zanaya-element="icon" id="i_5Jfazi" data-class-marker="classMark_icon_4GjCeN"></i>
</div>
<div class="col-lg-6 zanaya-inner-col col-md-9 col-sm-10 col-xs-9">
<div class="zanaya-counter clearfix zanaya-primary-color classMark_counter_x7sxll" data-zanaya-element="counter" data-counter-start="0" data-counter-end="12" data-counter-separator="" data-counter-decimals="" data-counter-duration="" data-counter-prefix="" data-counter-suffix="" id="div_OEbYhB" data-class-marker="classMark_counter_x7sxll">2</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col classMark_inner-column_YYAgHk text-lg-center" id="div_s0kknp" data-class-marker="classMark_inner-column_YYAgHk">
<div data-zanaya-element="text-block" class="clearfix">
<h5 class="classMark_h5_mjgjom" id="h5_b6PefG" data-class-marker="classMark_h5_mjgjom">Sharing Options</h5>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 zanaya-col">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-lg-6 zanaya-inner-col classMark_inner-column_Sf37Ht text-lg-right col-md-5 col-sm-5 col-xs-4" id="div_SmUjvP" data-class-marker="classMark_inner-column_Sf37Ht">
						<i class="zanaya-icon clearfix zanaya-primary-color hidden-border xxl classMark_icon_qjKarv fa fa-paw" data-zanaya-element="icon" id="i_uTT803" data-class-marker="classMark_icon_qjKarv"></i>
</div>
<div class="col-lg-6 zanaya-inner-col col-md-9 col-sm-10 col-xs-9">
<div class="zanaya-counter clearfix zanaya-primary-color classMark_counter_UPYt7k" data-zanaya-element="counter" data-counter-start="0" data-counter-end="11" data-counter-separator="" data-counter-decimals="" data-counter-duration="" data-counter-prefix="" data-counter-suffix="" id="div_GEKb7W" data-class-marker="classMark_counter_UPYt7k">2</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col classMark_inner-column_YYAgHk text-lg-center" id="div_tzfmkm" data-class-marker="classMark_inner-column_YYAgHk">
<div data-zanaya-element="text-block" class="clearfix">
<h5 class="classMark_h5_mjgjom" id="h5_rEKxmW" data-class-marker="classMark_h5_mjgjom">Easy Steps</h5>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 zanaya-col">
<div class="clearfix zanaya-inner-row" data-row-layout="1|2">
<div class="col-lg-6 zanaya-inner-col classMark_inner-column_Sf37Ht text-lg-right col-md-5 col-sm-5 col-xs-4" id="div_hV2Q1S" data-class-marker="classMark_inner-column_Sf37Ht">
						<i class="zanaya-icon clearfix zanaya-primary-color hidden-border xxl classMark_icon_HtOqGP fa fa-compress" data-zanaya-element="icon" id="i_2Fc0c3" data-class-marker="classMark_icon_HtOqGP"></i>
</div>
<div class="col-lg-6 zanaya-inner-col col-md-9 col-sm-10 col-xs-9">
<div class="zanaya-counter clearfix zanaya-primary-color classMark_counter_m7nkEh" data-zanaya-element="counter" data-counter-start="0" data-counter-end="6" data-counter-separator="" data-counter-decimals="" data-counter-duration="" data-counter-prefix="" data-counter-suffix="" id="div_VIaxCu" data-class-marker="classMark_counter_m7nkEh">1</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col classMark_inner-column_YYAgHk text-lg-center" id="div_Zpc1WV" data-class-marker="classMark_inner-column_YYAgHk">
<div data-zanaya-element="text-block" class="clearfix">
<h5 class="classMark_h5_mjgjom" id="h5_J22HNf" data-class-marker="classMark_h5_mjgjom">Responsive Settings</h5>
</div>
</div>
</div>
</div>
</div>
</div>



<div class="container zanaya-section zanaya-background slr__team-7_div classMark_section_85ybw9" data-width="558" data-height="235" data-parallax-bg-size="contain" id="div_85ybw9" data-class-marker="classMark_section_85ybw9">
<div class="zanaya-row clearfix container" data-row-layout="1|1">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-col text-lg-center">
<div data-zanaya-element="text-block" class="clearfix">
<h2 id="h2_4cneZW" class="classMark_h2_wteEtG" data-class-marker="classMark_h2_wteEtG">Team <span class="texteditor-inline-color classMark_span_jihYtz" id="span_lov5xK" data-class-marker="classMark_span_jihYtz">Members</span></h2>
</div>
</div>
</div>
<div class="zanaya-row clearfix container slr__team-7_row z-mb-0 classMark_row_cReWp4" data-row-layout="1|1" id="div_07nel0" data-class-marker="classMark_row_cReWp4">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-col text-lg-center slr__team-7_col classMark_column_Qi7Eiy" id="div_6FYS3t" data-class-marker="classMark_column_Qi7Eiy">
<div data-zanaya-element="text-block" class="clearfix">
<!--<p class="classMark_p_izjpNo" id="p_a3UiVo" data-class-marker="classMark_p_izjpNo">Amet facilisis magna etiam tempor orci eu lobortis elementum <br class="zanaya-br">
nibharcu dictum varius duis at consectetur lorem donec</p>-->


</div>
<div data-zanaya-element="image" class="clearfix">
					<img class="img-responsive pull-center-lg zanaya-keep-src classMark_img_c832kM" src="https://retro.nouvellothemes.com/wp-content/uploads/2020/01/spacer.png" alt="image description" id="img_DiFFeg" data-class-marker="classMark_img_c832kM" data-attachment-id="14204"></div>
</div>
</div>
<div class="zanaya-row clearfix container classMark_row_rPKLm6" data-row-layout="1|4" id="row_rPKLm6" data-class-marker="classMark_row_rPKLm6">

<?php 
	$head = App\Teams::where('head', 1)->where('publication_status', 1)->get();
?>

<?php $__currentLoopData = $head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-3 col-md-3 col-xs-12 zanaya-col slr__team-7_col_2 col-sm-6">
<div data-zanaya-element="gallery" class="clearfix zanaya-hoverable slr__team-7_gallery classMark_gallery_y4U9S6" data-zanaya-element-theme="zanaya-hoverable" data-class-marker="classMark_gallery_y4U9S6" id="div_Eo2e6g">
<div class="zanaya-gallery-item pull-center-lg zanaya-hover-blur classMark_div_b76Ong" id="div_y0u1Rk" data-class-marker="classMark_div_b76Ong">
						<img class="img-responsive pull-center-lg zanaya-keep-src slr__team-7_img classMark_img_7oPTMn" src="<?php echo e(URL::to($heads->images)); ?>" alt="image description" data-width="500" data-height="500" id="img_EYiYVG" data-class-marker="classMark_img_7oPTMn" data-attachment-id="14220" style="height: 150px; width: 150px;">
<div class="zanaya-caption-wrap caption-vertical-center">
<div class="zanaya-caption">
<h3 class="slr__team-7_h3">+</h3>
</div>
</div>
</div>
</div>

<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col text-lg-center">
	<div data-zanaya-element="text-block" class="clearfix">
		<h6 class="zanaya-uppercase z-mb-0" data-custom-classes="zanaya-uppercase"><?php echo e($heads->name); ?></h6>
	</div>
	<div data-zanaya-element="text-block" class="clearfix">
		<small class="zanaya-primary-color" data-custom-classes="zanaya-primary-color"><?php echo e($heads->skill); ?></small>
	</div>
<a href="<?php echo e($heads->facebook); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-facebook-f z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_oq0A10"></i></a>


<a href="<?php echo e($heads->instagram); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-instagram z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_BccvJH"></i></a>
  

<a href="<?php echo e($heads->twitter); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-twitter z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_TAFCF2"></i></a>
  

<a href="mailto:<?php echo e($heads->mail); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color far fa-envelope slr__team-7_icon" data-zanaya-element="icon" id="i_5SPSgs"></i></a>

		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php 
	$head = App\Teams::where('head',NULL)->where('publication_status', 1)->get();
?>

<?php $__currentLoopData = $head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-3 col-md-3 col-xs-12 zanaya-col slr__team-7_col_2 col-sm-6">
<div data-zanaya-element="gallery" class="clearfix zanaya-hoverable slr__team-7_gallery classMark_gallery_y4U9S6" data-zanaya-element-theme="zanaya-hoverable" data-class-marker="classMark_gallery_y4U9S6" id="div_Eo2e6g">
<div class="zanaya-gallery-item pull-center-lg zanaya-hover-blur classMark_div_b76Ong" id="div_y0u1Rk" data-class-marker="classMark_div_b76Ong">
						<img class="img-responsive pull-center-lg zanaya-keep-src slr__team-7_img classMark_img_7oPTMn" src="<?php echo e(URL::to($heads->images)); ?>" alt="image description" data-width="500" data-height="500" id="img_EYiYVG" data-class-marker="classMark_img_7oPTMn" data-attachment-id="14220" style="height: 150px; width: 150px;">
<div class="zanaya-caption-wrap caption-vertical-center">
<div class="zanaya-caption">
<h3 class="slr__team-7_h3">+</h3>
</div>
</div>
</div>
</div>

<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col text-lg-center">
	<div data-zanaya-element="text-block" class="clearfix">
		<h6 class="zanaya-uppercase z-mb-0" data-custom-classes="zanaya-uppercase"><?php echo e($heads->name); ?></h6>
	</div>
	<div data-zanaya-element="text-block" class="clearfix">
		<small class="zanaya-primary-color" data-custom-classes="zanaya-primary-color"><?php echo e($heads->skill); ?></small>
	</div>
<a href="<?php echo e($heads->facebook); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-facebook-f z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_oq0A10"></i></a>


<a href="<?php echo e($heads->instagram); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-instagram z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_BccvJH"></i></a>
  

<a href="<?php echo e($heads->twitter); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-twitter z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_TAFCF2"></i></a>
  

<a href="mailto:<?php echo e($heads->mail); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color far fa-envelope slr__team-7_icon" data-zanaya-element="icon" id="i_5SPSgs"></i></a>

		</div>
	</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php 
	$head = App\Teams::where('head',0)->where('publication_status', 1)->get();
?>

<?php $__currentLoopData = $head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-3 col-md-3 col-xs-12 zanaya-col slr__team-7_col_2 col-sm-6">
<div data-zanaya-element="gallery" class="clearfix zanaya-hoverable slr__team-7_gallery classMark_gallery_y4U9S6" data-zanaya-element-theme="zanaya-hoverable" data-class-marker="classMark_gallery_y4U9S6" id="div_Eo2e6g">
<div class="zanaya-gallery-item pull-center-lg zanaya-hover-blur classMark_div_b76Ong" id="div_y0u1Rk" data-class-marker="classMark_div_b76Ong">
						<img class="img-responsive pull-center-lg zanaya-keep-src slr__team-7_img classMark_img_7oPTMn" src="<?php echo e(URL::to($heads->images)); ?>" alt="image description" data-width="500" data-height="500" id="img_EYiYVG" data-class-marker="classMark_img_7oPTMn" data-attachment-id="14220" style="height: 150px; width: 150px;">
<div class="zanaya-caption-wrap caption-vertical-center">
<div class="zanaya-caption">
<h3 class="slr__team-7_h3">+</h3>
</div>
</div>
</div>
</div>

<div class="clearfix zanaya-inner-row" data-row-layout="1|1">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-inner-col text-lg-center">
	<div data-zanaya-element="text-block" class="clearfix">
		<h6 class="zanaya-uppercase z-mb-0" data-custom-classes="zanaya-uppercase"><?php echo e($heads->name); ?></h6>
	</div>
	<div data-zanaya-element="text-block" class="clearfix">
		<small class="zanaya-primary-color" data-custom-classes="zanaya-primary-color"><?php echo e($heads->skill); ?></small>
	</div>
<a href="<?php echo e($heads->facebook); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-facebook-f z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_oq0A10"></i></a>


<a href="<?php echo e($heads->instagram); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-instagram z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_BccvJH"></i></a>
  

<a href="<?php echo e($heads->twitter); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color fab fa-twitter z-mr-1 slr__team-7_icon" data-zanaya-element="icon" id="i_TAFCF2"></i></a>
  

<a href="mailto:<?php echo e($heads->mail); ?>"><i class="zanaya-icon lg circle-border clearfix zanaya-primary-color far fa-envelope slr__team-7_icon" data-zanaya-element="icon" id="i_5SPSgs"></i></a>

		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
							
	



<div class="container zanaya-section zanaya-background classMark_section_uJsTzm" id="div_yMTb4J" data-class-marker="classMark_section_uJsTzm">
		<div class="zanaya-row clearfix container" data-row-layout="1|1">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 zanaya-col classMark_column_5AgzI8 parallax-scroll parallax-scroll-parent" id="div_Rb4reG" data-class-marker="classMark_column_5AgzI8" data-parallax="{&quot;scale&quot;:&quot;1.5&quot;,&quot;smoothness&quot;:&quot;30&quot;}">
				<div data-zanaya-element="text-block" class="clearfix">
					<h2 class="classMark_h2_LpT5MU" id="h2_TCj9k0" data-class-marker="classMark_h2_LpT5MU">Ready to start your project with Splent?&nbsp;</h2>
				</div>
				<button class="btn zanaya-btn button-size-large button-text-small button-color-primary clearfix button-shape-sharp classMark_button_k5kHFU center-block-lg" data-zanaya-element="button" id="button_uwRoKK" data-class-marker="classMark_button_k5kHFU">lets&nbsp;start
				</button>
				
			</div>
		</div>
	</div>	


</div>
	<!-- .entry-content -->

</article><!-- #post-## -->

<div class="pagination-wrap ">
</div>
</div> <!-- //primary-content-wrapper -->						
</main><!-- #main -->

</div><!-- #primary -->

					 

										
										
</div><!-- zanaya-row -->

														
</div><!-- #content-->
		<!-- END CONTENT -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamIT\resources\views/fontend/home.blade.php ENDPATH**/ ?>