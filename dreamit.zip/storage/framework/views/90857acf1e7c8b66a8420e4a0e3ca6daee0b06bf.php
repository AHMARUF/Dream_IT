
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
<!-- Example DataTables Card-->
  <div class="card mb-3">
    <div class="card-header">
      <i class="fa fa-table"></i> Data Table Example</div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>SL</th>
              <th>Title</th>
              <th>Images</th>
              <th>Description</th>
              
              
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>SL</th>
              <th>Title</th>
              <th>Images</th>
              <th>Description</th>
              
              
              <th>Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php $__currentLoopData = $Service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$Services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$key); ?></td>
              <td><?php echo e($Services->title); ?></td>
              <td><img src="<?php echo e(URL::to($Services->images)); ?>" height="80" width="80"></td>
              <td style="width: 35%;"><?php echo $Services->description; ?></td>
              
              
              <td> 
                <?php if($Services->publication_status==1): ?>
                <label class="bg-success pl-2 pr-2">Active</label>
                <?php else: ?>
                <label class="bg-danger pl-2 pr-2">Unactive</label>
                <?php endif; ?>
              </td>
              <td>
                <?php if($Services->publication_status==1): ?>
                <a href="<?php echo e(URL::to('/Service/unactive')); ?>/<?php echo e(Crypt::encryptString($Services->id)); ?>" class="btn btn-outline-danger">Unactive</a>
                <?php else: ?>
                <a href="<?php echo e(URL::to('Service/active')); ?>/<?php echo e(Crypt::encryptString($Services->id)); ?>" class="btn btn-outline-success">Active</a>
                <?php endif; ?>
                <a href="<?php echo e(URL::to('/eidt/Service')); ?>/<?php echo e(Crypt::encryptString($Services->id)); ?>" class="btn btn-outline-warning">Eidt</a>
                <a href="<?php echo e(URL::to('/delete/Service')); ?>/<?php echo e(Crypt::encryptString($Services->id)); ?>" id="delete" class="btn btn-outline-danger">Delete</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
</div></div>
<!-- /.container-fluid-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamIT\resources\views/backend/service/all.blade.php ENDPATH**/ ?>