
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-8 m-auto py-2 border-red" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);">
				<div class="card" >
					 <?php if($errors->any()): ?>
				      <div class="alert alert-danger">
				          <ul>
				              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                  <li><?php echo e($error); ?></li>
				              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				          </ul>
				      </div>
				    <?php endif; ?>
	                <div class="card-body">
	                    <h4 class="card-title">Team Add Page</h4><hr>
	                    <form class="mt-4" method="POST" action="<?php echo e(route('Team.store')); ?>" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
	                        <div class="form-group">
	                        	<label>Name</label>
	                            <input type="text" class="form-control" name="name">
	                        </div>
	                        <div class="form-group">
	                        	<label>Skill</label>
	                        	<input type="text" class="form-control" name="skill">
	                        </div>
	                        <div class="form-group">
	                        	<label>Facebook</label>
	                        	<input type="text" class="form-control" name="facebook" >
	                        </div>
	                        <div class="form-group">
	                        	<label>Instagram</label>
	                        	<input type="text" class="form-control" name="instagram" >
	                        </div>
	                        <div class="form-group">
	                        	<label>Twitter</label>
	                        	<input type="text" class="form-control" name="twitter" >
	                        </div>
	                        <div class="form-group">
	                        	<label>E-mail</label>
	                        	<input type="text" class="form-control" name="mail">
	                        </div>
	                        <div class="form-group">
	                        	<label>File</label>
	                            <input type="file" class="form-control" name="images">
	                        </div>
	                        <div class="form-group">
	                        	<label>Junior</label>
	                            <input type="checkbox"  name="head" value="1">
	                        </div>
	                        <div class="form-group">
	                        	<label>Publication Status</label>
	                            <input type="checkbox"  name="publication_status" value="1">
	                        </div>
	                        <div class="form-group">
	                            <button class="btn btn-success">Save</button>
	                        </div>
	                    </form>
	                </div>
	            </div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamIT\resources\views/backend/team/add.blade.php ENDPATH**/ ?>